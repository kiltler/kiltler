# AlexCool — Android App Icons

Два варианта на выбор. Установить можно любой.

## Структура

Каждый вариант содержит готовую папку `res/`, которую можно положить
в `app/src/main/res/` вашего Android-проекта. Файлы:

```
res/
├─ mipmap-mdpi/      ic_launcher.png (48×48), ic_launcher_round.png, ic_launcher_foreground.png
├─ mipmap-hdpi/      ic_launcher.png (72×72), ic_launcher_round.png, ic_launcher_foreground.png
├─ mipmap-xhdpi/     ic_launcher.png (96×96), ic_launcher_round.png, ic_launcher_foreground.png
├─ mipmap-xxhdpi/    ic_launcher.png (144×144), ic_launcher_round.png, ic_launcher_foreground.png
├─ mipmap-xxxhdpi/   ic_launcher.png (192×192), ic_launcher_round.png, ic_launcher_foreground.png
├─ mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml  (adaptive icon, Android 8.0+)
└─ values/           ic_launcher_background.xml  (цвет фона adaptive icon)
```

Отдельно `playstore_icon_512.png` — для загрузки в Google Play Console.

## Установка (Android Studio)

1. Откройте проект.
2. Скопируйте содержимое папки `res/` выбранного варианта в
   `app/src/main/res/` (с заменой существующих файлов).
3. В `AndroidManifest.xml` уже должна быть ссылка:
   ```xml
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"
   ```
4. Пересоберите проект (Build → Rebuild Project).

## Варианты

- **variant_1_white_background** — белый фон. Точное соответствие
  оригинальному логотипу, чистый минималистичный вид.
- **variant_2_brand_gradient** — фирменный градиент (голубой → тёмно-синий).
  Заметнее на экране, лучше выделяется среди других приложений.

## Размеры

| Плотность   | Размер (px) |
|-------------|-------------|
| mdpi        | 48×48       |
| hdpi        | 72×72       |
| xhdpi       | 96×96       |
| xxhdpi      | 144×144     |
| xxxhdpi     | 192×192     |
| Play Store  | 512×512     |
